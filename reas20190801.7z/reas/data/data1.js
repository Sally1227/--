var tableListData = [
  {
    "id": "10000003",
    "projectId": "20000001",
    "projectName": "项目1",
    "inquiryId": "30000001",
    "instType": "1",
    "instId": "40000001",
    "instBranch": "50000001",
    "businessPeople": "张利",
    "inquirer": "管理员",
    "price": null,
    "remark1": null,
    "remark2": null,

  },
  {
    "id": "10000004",
    "projectId": "20000001",
    "projectName": "项目1",
    "inquiryId": "30000002",
    "instType": "2",
    "instId": "40000004",
    "instBranch": "50000008",
    "businessPeople": "章伊",
    "inquirer": "管理员",
    "price": null,
    "remark1": null,
    "remark2": null,
  },
  {
    "id": "10000005",
    "projectId": "20000002",
    "projectName": "项目2",
    "inquiryId": "30000003",
    "instType": "1",
    "instId": "40000002",
    "instBranch": "50000004",
    "businessPeople": "吴丽",
    "inquirer": "管理员",
    "price": null,
    "remark1": null,
    "remark2": null,
  }
];

var detailData = [
  {
    "id": "10000003",
    "projectId": "20000001",
    "projectName": "项目1",
    "inquiryId": "30000001",
    "instType": "1",
    "instId": "40000001",
    "instBranch": "50000001",
    "businessPeople": "张利",
    "inquirer": "管理员",
    "price": null,
    "remark1": null,
    "remark2": null,

  },
  {
    "id": "10000004",
    "projectId": "20000001",
    "projectName": "项目1",
    "inquiryId": "30000002",
    "instType": "2",
    "instId": "40000004",
    "instBranch": "50000008",
    "businessPeople": "章伊",
    "inquirer": "管理员",
    "price": null,
    "remark1": null,
    "remark2": null,
  },
];




/* 未提交的询价信息 */
var uncommitted_inquiry = [
  {
    "id": "10000001",
    "projectId": "20000001",
    "projectName": "项目1",
    "inquiryId": "30000001",
    "instType": "1",
    "instId": "40000001",
    "instBranch": "50000001",
    "businessPeople": "张利",
    "inquirer": "管理员",

  },
  {
    "id": "10000002",
    "projectId": "20000001",
    "projectName": "项目1",
    "inquiryId": "30000002",
    "instType": "2",
    "instId": "40000004",
    "instBranch": "50000008",
    "businessPeople": "章伊",
    "inquirer": "管理员",

  }
];
/* 机构名称 */
var inst_data = {
  "1": [
    {
      "id": "40000001",
      "instType": "1",
      "instName": "平安银行",
      "isBranch": "0",
      "contact": "张三",
    },
    {
      "id": "40000002",
      "instType": "1",
      "instName": "中国银行",
      "isBranch": "0",
      "contact": "李四",
    }
  ],
  "2": [
    {
      "id": "40000003",
      "instType": "2",
      "instName": "东莞法院",
      "isBranch": "0",
      "contact": "王五",
    },
    {
      "id": "40000004",
      "instType": "2",
      "instName": "深圳法院",
      "isBranch": "0",
      "contact": "赵六",
    },
      {
          "id": "40000005",
          "instType": "2",
          "instName": "上海法院",
          "isBranch": "0",
          "contact": "王佳",
      }
  ]
};

/* 分支机构 */
var instBranch_data = {
  "40000001": [
    {
      "id": "50000001",
      "instType": "1",
      "instName": "平安银行-福田支行",
      "isBranch": "1",
      "contact": "张利",
    },
    {
      "id": "50000002",
      "instType": "1",
      "instName": "平安银行-罗湖支行",
      "isBranch": "1",
      "contact": "王慧",
    }
  ],
  "40000002": [
    {
      "id": "50000003",
      "instType": "1",
      "instName": "中国银行-上沙支行",
      "isBranch": "1",
      "contact": "李辉",

    },
    {
      "id": "50000004",
      "instType": "1",
      "instName": "中国银行-下沙支行",
      "isBranch": "1",
      "contact": "吴丽",

    }
  ],
  "40000003": [
    {
      "id": "50000005",
      "instType": "2",
      "instName": "东莞法院-上沙分支",
      "isBranch": "1",
      "contact": "吴霞",

    },
    {
      "id": "50000006",
      "instType": "2",
      "instName": "东莞法院-沙井分支",
      "isBranch": "1",
      "contact": "吴浩",

    }
  ],
  "40000004": [
    {
      "id": "50000007",
      "instType": "2",
      "instName": "深圳法院-白石洲分支",
      "isBranch": "1",
      "contact": "罗慧",

    },
    {
      "id": "50000008",
      "instType": "2",
      "instName": "深圳法院-西丽湖分支",
      "isBranch": "1",
      "contact": "章伊",

    }
  ]
};

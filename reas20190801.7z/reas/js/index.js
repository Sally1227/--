

//操作栏的格式化
function actionFormatter(value, row, index) {
    var id = value;
    var result = "";
    result += "<a href='javascript:;' class='btn btn-xs green' onclick=\"seeViewById('" + row + "', view='view')\" title='查看'><span class='glyphicon glyphicon-search'></span></a>";
    result += "<a href='javascript:;' class='btn btn-xs green' onclick=\"editViewById('" + row + "', view='view')\" title='修改'><span class='glyphicon glyphicon-edit'></span></a>";
    result += "<a href='javascript:;' class='btn btn-xs green' onclick=\"onBlackPrice('" + row + "', view='view')\" title='回价'><span class='glyphicon glyphicon-pencil'></span></a>";
    /*result += '<a href="javascript:;" class="btn btn-xs green btn-see" title="查看"><span class="glyphicon glyphicon-search"></span></a>';
    result += '<a href="javascript:;" class="btn btn-xs green btn-edit" onclick="editViewById(' + row + ')" title="修改"><span class="glyphicon glyphicon-edit"></span></a>';
    result += '<a href="javascript:;" class="btn btn-xs green btn-black" onclick="onBlackPrice(' + row + ')" title="回价"><span class="glyphicon glyphicon-pencil"></span></a>';*/
    // result += "<a href='javascript:;' class='btn btn-xs red' onclick=\"deleteByIds('" + id + "')\" title='删除'><span class='glyphicon glyphicon-remove'></span></a>";
    return result;
}

/* 获取 详情内容 html */
function getHtml(keys, value, index) {
    var html = '';
    html += '<div class="row">';
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (inquiryField[key]) {
            html += "<div class='col-xs-6 col-md-3 mrb10'><span>"+ inquiryField[key] +"：</span><span>"+ value[key] +"</span></div>";
        }
    }
    html += "</div>";

    return html;
}

/* 第二步表单html */
function getFormHtml(value) {
    var html = '<div class="row border-top mrt20 pdt10">';
    html += '<div class="col-md-4 mrb10"><label>回价价格</label><div><input name="price" value="'+ value.price +'" type="text" class="form-control input-sm"></div></div>';
    html += '<div class="col-md-4 mrb10"><label>备注1</label><div><input name="remark1" value="'+ value.remark1 +'" type="text"  class="form-control input-sm"></div></div>';
    html += '<div class="col-md-4 mrb10"><label>备注2</label><div><input name="remark2" value="'+ value.remark2 +'" type="text" class="form-control input-sm"></div></div>';
    html += '</div>';
    return html;
}

/* 详情 */
function seeViewById(row) {
    $('#detailModal').modal('show');
    $('#detailModal').on('shown.bs.modal', function () {
        $('#detailModal .panel-body').html('');
        $('#detailContent .nav-tabs').html('');

        var keys = Object.keys(detailData[0]);
        var itemNav = '';
        var itemContent = '';
        for (var j = 0; j < detailData.length; j++) {
            var index = j + 1;
            if (j == 0) {
                itemNav += '<li role="presentation" class="active"><a href="#detail-nav'+ index +'" role="tab" data-toggle="tab">询价'+index+'</a></li>';
                itemContent += '<div role="tabpanel" class="tab-pane active" id="detail-nav'+index+'"><div class="mr20">'+getHtml(keys, detailData[j], index)+'</div></div>';
            } else {
                itemNav += '<li role="presentation"><a href="#detail-nav'+ index +'" role="tab" data-toggle="tab">询价'+index+'</a></li>';
                itemContent += '<div role="tabpanel" class="tab-pane" id="detail-nav'+index+'"><div class="mr20">'+getHtml(keys, detailData[j], index)+'</div></div>';
            }
        }
        console.log(itemNav);

        $('#detailContent .nav-tabs').html(itemNav);
        $('#detailContent .tab-content').html(itemContent);

        for (var i = 0; i < detailData.length; i++) {
            $('#detailModal .panel-body').append(getHtml(keys, detailData[i], i+1));
        }
    });
}

/* 修改 */
function editViewById(row) {
    var arr = [];
    for (var i = 0; i < detailData.length; i++) {
       var item = {label: '', value: ''};
       item.label = detailData[i].name1
    }
}

/* 回价 */
function onBlackPrice(row) {
    $('#hjModal').modal('show');
    $('#hjModal').on('shown.bs.modal', function () {
        $('#hjContent .nav-tabs').html('');

        var keys = Object.keys(detailData[0]);
        var itemNav = '';
        var itemContent = '';
        for (var j = 0; j < detailData.length; j++) {
            var index = j + 1;
            if (j == 0) {
                itemNav += '<li role="presentation" class="active"><a href="#hj-nav'+ index +'" role="tab" data-toggle="tab">询价'+index+'</a></li>';
                itemContent += '<div role="tabpanel" class="tab-pane active" id="hj-nav'+index+'"><div class="mr20">'+getHtml(keys, detailData[j], index)+getFormHtml(detailData[j])+'</div></div>';
            } else {
                itemNav += '<li role="presentation"><a href="#hj-nav'+ index +'" role="tab" data-toggle="tab">询价'+index+'</a></li>';
                itemContent += '<div role="tabpanel" class="tab-pane" id="hj-nav'+index+'"><div class="mr20">'+getHtml(keys, detailData[j], index)+getFormHtml(detailData[j])+'</div></div>';
            }
        }

        $('#hjContent .nav-tabs').html(itemNav);
        $('#hjContent .tab-content').html(itemContent);
    });
}
 
function deleteByIds() {
    
}

$(function () {


    var randomIdNum = 400;
    $('#add').click(function () {
        randomIdNum += 9;
        var inputVal = $('#name').val();
        var htmlNav = "<li role='presentation'><a href='#"+ inputVal +"' aria-controls='" + inputVal + "' role='tab' data-toggle='tab'>"+ inputVal +"</a></li>";
        var htmlContent = "<div role='tabpanel' class='tab-pane' id='"+ inputVal +"'> <div><form onsubmit='return submitFun(this);'><input type='text' id='userName"+ randomIdNum + "' name='userName'><button type='submit' class='btn btn-sm btn-info'>提交</button></form></div>" + inputVal + "</div>";
        $('#nav-tabs').append(htmlNav);
        $('#tab-content').append(htmlContent);
    });




    /* 表格 */
    var $table = $('#table');
    $table.bootstrapTable({
        data: tableListData,
        uniqueId: 'ID',
        pageSize: '10',
        showRefresh: true,
        maintainSelected: true,
        columns: [
            {
                field: 'projectId',
                title: '操作',
                width: 120,
                align: 'center',
                valign: 'middle',
                formatter: actionFormatter,
            },
            {
                field: 'projectName',
                title: '项目姓名'
            },
            {
                field: 'id',
                title: '编号ID'
            },
            {
                field: 'instType',
                title: '机构类型'
            },
            {
                field: 'instId',
                title: '委托方'
            },
            {
                field: 'instBranch',
                title: '分支机构'
            },
            {
                field: 'businessPeople',
                title: '业务员'
            },
            {
                field: 'inquirer',
                title: '询价员'
            }

        ],
        onLoadSuccess: function () {
            //合并单元格
            mergeCells(tableListData, "projectName", 1,$('#table'));
            mergeCells(tableListData, "projectId", 1,$('#table'));
        }
    });

    mergeCells(tableListData, "projectName", 1,$('#table'));
    mergeCells(tableListData, "projectId", 1,$('#table'));

    function mergeCells(data,fieldName,colspan,target){
        //声明一个map计算相同属性值在data对象出现的次数和
        var sortMap = {};
        for(var i = 0 ; i < data.length ; i++){
            for(var prop in data[i]){
                if(prop == fieldName){
                    var key = data[i][prop]
                    if(sortMap.hasOwnProperty(key)){
                        sortMap[key] = sortMap[key] * 1 + 1;
                    } else {
                        sortMap[key] = 1;
                    }
                    break;
                }
            }
        }
        for(var prop in sortMap){
            console.log(prop,sortMap[prop])
        }
        var index = 0;
        for(var prop in sortMap){
            var count = sortMap[prop] * 1;
            $(target).bootstrapTable('mergeCells',{index:index, field:fieldName, colspan: colspan, rowspan: count});
            index += count;
        }
    }

});



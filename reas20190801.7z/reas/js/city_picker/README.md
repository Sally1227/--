# city_picker
### 一款好看的基于jquery的省市区三级插件（省市区数据引用自mui的city.data-3.js）
水平有限，欢迎提出修改意见和见解。你的鼓励是我最大的动力。

[在线Demo](http://hi_wendy.gitee.io/city_picker/)

![输入图片说明](http://img0.ph.126.net/fO_TrZuaYOJiliNrknMzDQ==/1664080062413806731.png "在这里输入图片标题")
![输入图片说明](http://img1.ph.126.net/9PgqrKq9Rz28miZ__6EPEQ==/5717544027319224640.png "在这里输入图片标题")
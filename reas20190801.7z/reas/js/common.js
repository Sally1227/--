/* 定义一个询价的对象 */
var Inquiry = {
    createNew: function () {
        var inquiryBo = {};
        inquiryBo.id = null;
        inquiryBo.projectId = null;
        inquiryBo.projectName = null;
        inquiryBo.inquiryId = null;
        inquiryBo.instType = null;
        inquiryBo.instId = null;
        inquiryBo.instBranch = null;
        inquiryBo.businessPeople = null;
        inquiryBo.inquirer = null;
        inquiryBo.price = null;
        inquiryBo.remark1 = null;
        inquiryBo.remark2 = null;
        return inquiryBo;
    }
};


var inquiryField = {
    "projectId": "项目ID",
    "projectName": "项目名称",
    "instType": "机构类型",
    "instId": "委托方",
    "instBranch": "分支机构",
    "businessPeople": "业务员",
    "inquirer": "询价员",
    "price": "价格",
    "remark1": "备注1",
    "remark2": "备注2",
};
